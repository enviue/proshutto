module.exports = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    maxWidth: {
      '8xl': '1440px',
    },
    extend: {
      colors: {
        "bg-dark": "#282F3B",
        "orange": "#F77F00",
        "bg-light": "#E5E5E5"
      },
      spacing: {
        "18px": "18px",
        "8xl": "1440px",
        "460px": "460px",
      }
    },
  },
  plugins: [],
}
