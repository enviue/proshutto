import React from 'react'
import BigLogo from './svg/bigLogo'
import Search from './svg/search'
const Poisk = () => {
    return (
        <div className='flex justify-center flex-col items-center'>
            <div className='mt-36'>
                <BigLogo />

            </div>
            <div className='w-5/6 flex justify-center'>
                <input type="text" placeholder='Search...' className='rounded-md p-2 mt-12 w-460px' />
            </div>

        </div >
    )
}

export default Poisk
