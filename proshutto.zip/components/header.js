import Info from "./info"
import Logo from "./logo"
import Social_n_links from "./social_n_links"


const Header = () => {
    return (
        <div className="bg-bg-dark flex justify-center py-4">
            <div className="flex max-w-8xl justify-between">
                <Logo />
                <Info />
                <Social_n_links />
            </div>

        </div>
    )
}

export default Header
