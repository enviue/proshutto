export default function Search(params) {
    return (
        <svg width="28" height="29" viewBox="0 0 28 29" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="11.6665" cy="12.0952" r="8.75" stroke="white" strokeWidth="1.8" />
            <path d="M24.5002 24.9284L18.0835 18.5117" stroke="white" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
        </svg>

    );
}