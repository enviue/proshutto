

const Info = () => {
    return (
        <div className="text-white hidden 2xl:flex justify-evenly gap-x-18px mr-12 lg:ml-96 2xl:ml-460px">
            <a>
                Top Projects
            </a>
            <a>
                Manifesto
            </a>
            <a>
                Careers
            </a>
        </div>
    )
}

export default Info
