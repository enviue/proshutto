import React from 'react'
import Facebook from './svg/facebook'
import Search from './svg/search'
import Telegram from './svg/telegram'
import Twitter from './svg/twitter'

const Social_n_links = () => {

    const links = [
        {
            href: "twitter.com",
            img: <Twitter />

        },
        {
            href: "https://www.facebook.com/",
            img: <Facebook />
        },
        {
            href: "telegram.com",
            img: <Telegram />
        }
    ]

    return (
        <div className='flex gap-4 '>
            <Search />

            {links.map((item, index) => (
                <a key={index} href={item.href}>
                    {item.img}
                </a>
            ))}
        </div>
    )
}

export default Social_n_links
