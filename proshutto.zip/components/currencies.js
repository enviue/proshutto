

const Currencies = () => {

    const currencies = [
        {
            value: "BTC",
            current: "56,658",
            prev: "57,078",
            diff: "-0.42"

        },
        {
            value: "BTC",
            current: "56,658",
            prev: "57,078",
            diff: "-0.42"

        },
        {
            value: "BTC",
            current: "56,658",
            prev: "57,078",
            diff: "-0.42"

        },
        {
            value: "BTC",
            current: "56,658",
            prev: "57,078",
            diff: "-0.42"

        },
        {
            value: "BTC",
            current: "56,658",
            prev: "57,078",
            diff: "-0.42"

        },
        {
            value: "BTC",
            current: "56,658",
            prev: "57,078",
            diff: "-0.42"

        },
        {
            value: "BTC",
            current: "56,658",
            prev: "57,078",
            diff: "-0.42"

        },
        {
            value: "BTC",
            current: "56,658",
            prev: "57,078",
            diff: "-0.42"

        },
        {
            value: "BTC",
            current: "56,658",
            prev: "57,078",
            diff: "-0.42"

        }

    ]

    return (
        <div className="bg-bg-dark mt-px">
            <div className="max-w-8xl py-4 flex gap-4">
                {currencies.map((item, index) => (
                    <div key={index} className=" text-white text-xs flex gap-1">
                        <p>
                            {item.value}

                        </p>
                        <p>${item.current}</p>
                        <p>{item.diff}%</p>
                    </div>
                ))}
            </div>
        </div>
    )
}

export default Currencies
